<?php include 'header.php';?>
      <!-- Breadcrumb Section - Start
        ================================================== -->
      <section class="breadcrumb_section text-center"
        style="background-image: url(assets/images/backgrounds/infra.jpeg);">
        <div class="container">
          <h1 class="page_title text-uppercase">Infrastructure</h1>
          <ul class="breadcrumb_nav ul_li_center text-uppercase">
            <li><a href="index.html">HOME</a></li>
            <li>Infrastructure</li>
          </ul>
        </div>
      </section>
      <!-- Breadcrumb Section - End
        ================================================== -->
<center>
  <h2>Our Infrastructure</h2>
  <p>
    <b>We believe in:</b><br>
• Best quality • On time availability • User friendly • Reasonable price • A valued services
  </p>
</center>
   

<br>
<div>
    <img src="assets/images/bgf.png" style="width: 2000px;">
</div>
<br>
<p>
 <b> Complete Peace of Mind: </b><br>We enable our customer to sit back, relax and don’t worry, if anything 
goes wrong they will know about it, usually before anybody else and before it can impact their 
business.
</p>
<!-- <div class="grid-container">

  <div>1</div>
  <div>2</div>
  <div>3</div>  
  <div>4</div>
  <div>5</div>
  <div>6</div>
  <div>7</div>
  <div>8</div>
</div> -->


    </main>
    <!-- Main Body - End
      ================================================== -->

       <!-- Footer Section - Start
      ================================================== -->
      <?php include 'footer.php';?>